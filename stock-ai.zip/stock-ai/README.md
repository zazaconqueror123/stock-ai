# Stock AI — Asistente de Análisis de Acciones

App de análisis de acciones con IA, construida con Next.js y desplegada en Vercel.

---

## 🚀 Cómo publicar en Vercel (sin experiencia técnica)

### Paso 1 — Crear cuenta en GitHub
1. Ve a https://github.com y crea una cuenta gratuita
2. Haz clic en **"New repository"**
3. Ponle el nombre `stock-ai`
4. Marca "Public" y haz clic en **"Create repository"**

### Paso 2 — Subir los archivos
1. En tu nuevo repositorio, haz clic en **"uploading an existing file"**
2. Arrastra TODA la carpeta `stock-ai` que descargaste
3. Haz clic en **"Commit changes"**

### Paso 3 — Crear cuenta en Vercel
1. Ve a https://vercel.com
2. Haz clic en **"Sign up"** → **"Continue with GitHub"**
3. Autoriza Vercel a acceder a tu GitHub

### Paso 4 — Importar el proyecto
1. En Vercel, haz clic en **"Add New Project"**
2. Selecciona el repositorio `stock-ai`
3. Haz clic en **"Import"**

### Paso 5 — Agregar tu API key (MUY IMPORTANTE)
1. Antes de hacer Deploy, busca la sección **"Environment Variables"**
2. Agrega esta variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** tu API key de Anthropic (empieza con `sk-ant-...`)
3. Haz clic en **"Add"**

### Paso 6 — Deploy
1. Haz clic en **"Deploy"**
2. Espera 2-3 minutos
3. ¡Listo! Vercel te dará una URL como `stock-ai-tuusuario.vercel.app`

---

## 🔑 Cómo obtener tu API key de Anthropic
1. Ve a https://console.anthropic.com
2. Crea una cuenta o inicia sesión
3. Ve a **"API Keys"** → **"Create Key"**
4. Copia la key y guárdala en un lugar seguro

---

## 💡 Notas importantes
- La API key **nunca** es visible para los usuarios — está protegida en el servidor
- Cada análisis consume créditos de la API de Anthropic (~$0.01 por consulta)
- Puedes ver el uso en https://console.anthropic.com

---

## 🛠 Estructura del proyecto
```
stock-ai/
├── app/
│   ├── api/
│   │   ├── analyze/route.js   ← Backend: análisis de acciones
│   │   └── chat/route.js      ← Backend: preguntas de seguimiento
│   ├── globals.css
│   ├── layout.js
│   ├── page.js
│   ├── StockApp.js            ← Frontend principal
│   └── StockApp.module.css
├── package.json
├── next.config.js
└── README.md
```
