import StockApp from "./StockApp";

export const metadata = {
  title: "Stock AI — Análisis de Acciones",
  description: "Asistente de análisis de acciones con inteligencia artificial",
};

export default function Page() {
  return <StockApp />;
}
